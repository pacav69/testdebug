ALTER TABLE `#__unclebill` ADD `catid` int(11) NOT NULL DEFAULT '0'
