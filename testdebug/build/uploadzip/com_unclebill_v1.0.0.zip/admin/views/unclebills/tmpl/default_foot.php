<?php
// No direct access to this file
defined ( '_JEXEC' ) or die ( 'Restricted Access' );
?>
<tr>
	<td colspan="3"><?php echo $this->pagination->getListFooter(); ?></td>
</tr>
