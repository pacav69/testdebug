ALTER TABLE `#__dartsleague` ADD `params` VARCHAR(1024) NOT NULL DEFAULT '';
