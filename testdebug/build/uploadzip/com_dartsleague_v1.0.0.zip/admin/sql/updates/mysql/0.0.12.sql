ALTER TABLE `#__dartsleague` ADD `catid` int(11) NOT NULL DEFAULT '0'
